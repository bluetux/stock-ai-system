// src/pages/Dashboard.jsx
import React from "react";

const Dashboard = () => {
  return (
    <div className="text-white p-4">
      <h1 className="text-2xl font-bold">📊 Stock Dashboard</h1>
      <p className="mt-2 text-gray-300">
        여기에 AI 분석 결과, 주요 종목, 알림 등을 표시할 예정입니다.
      </p>
    </div>
  );
};

export default Dashboard;
